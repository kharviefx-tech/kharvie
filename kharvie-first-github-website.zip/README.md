# Kharvie — Official Artist Website

A simple responsive artist website built with plain HTML, CSS and JavaScript.

## Files

- `index.html` — website structure and content
- `style.css` — design and responsive layout
- `script.js` — mobile menu and current year

## Next edits

Replace:
- song titles and streaming links
- biography text
- video link
- email address
- social media links
- placeholder cover/video areas with official assets

This project can be deployed directly to Netlify or GitHub Pages.
